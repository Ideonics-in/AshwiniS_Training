<?php

class SMSConnector
   {

   function __construct()
      {
      }

   function CheckConfig()
      {
      }

   function Text()
      {
      }

   function ProcessedText()
      {
      }

   function Number()
      {
      }

   function UUID()
      {
      }

   function Time()
      {
      }

   function IPAddress()
      {
      }

    // confirm SMS received to API
   function Respond()
      {
      }

   // send SMS message via API
   function Send($number,$text)
      {
      }

   }

?>