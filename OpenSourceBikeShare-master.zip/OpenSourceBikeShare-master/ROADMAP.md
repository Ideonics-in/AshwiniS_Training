Open Source Bike Share Roadmap
============

Real-life testing
----------
1. Credit system
2. Thorough testing of all notifications
3. Web installation process

Development
----------
### Priorities
* Complete admin interface on web (not part of map)

### UX and functions
* terms of use
* notes for stands (e.g. problem with stand)

### Security
* Prepared SQL commands (XSS and co. prevention)

### Others
* https://github.com/mmmaly/OpenSourceBikeShare/issues?q=is%3Aissue+is%3Aopen
